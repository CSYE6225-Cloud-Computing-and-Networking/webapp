const database_config = {
    host : "127.0.0.1",
    user : "user1",
    password : "password1",
    dialect :"mariadb",
    database: "cloudDB"
}

export default database_config;
